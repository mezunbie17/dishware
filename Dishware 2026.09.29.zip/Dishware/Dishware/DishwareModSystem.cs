﻿using Dishware.Blocks;
using Dishware.Rendering;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.Server;
using Vintagestory.GameContent;

namespace Dishware
{
    public class DishwareModSystem : ModSystem
    {

        public override void Start(ICoreAPI api)
        {
            Mod.Logger.Notification("Hello from template mod: " + api.Side);

            api.RegisterBlockClass("BlockFilledPlate", typeof(BlockFilledPlate));
            api.RegisterBlockClass("DishwareBowlMeal", typeof(DishwareBowlMeal));
            api.RegisterBlockClass("DishwareBowlLiquid", typeof(DishwareBowlLiquid));
        }

        public override void StartServerSide(ICoreServerAPI api)
        {
            Mod.Logger.Notification("Hello from template mod server side: " + Lang.Get("dishware:hello"));
        }

        private ICoreClientAPI capi;
        public override void StartClientSide(ICoreClientAPI api)
        {
            Mod.Logger.Notification("Hello from template mod client side: " + Lang.Get("dishware:hello"));
            capi = api;
            api.Event.RegisterRenderer(new PlatePreviewRenderer(api), EnumRenderStage.AfterFinalComposition, "dishware-plate-preview");
            api.Event.MouseWheelMove += OnMouseWheelMove;

        }
        private void OnMouseWheelMove(MouseWheelEventArgs args)
        {
            IClientPlayer player = capi.World.Player;
            if (!player.Entity.Controls.ShiftKey) return;

            ItemSlot heldSlot = player.InventoryManager.ActiveHotbarSlot;
            if (heldSlot == null || heldSlot.Empty) return;

            BlockSelection blockSel = player.CurrentBlockSelection;
            if (blockSel == null) return;

            BlockEntityGroundStorage beg = capi.World.BlockAccessor.GetBlockEntity(blockSel.Position) as BlockEntityGroundStorage;
            ItemStack plateStack = beg?.Inventory?.FirstNonEmptySlot?.Itemstack;
            if (plateStack?.Block is not BlockFilledPlate plate) return;
            if (!plate.IsPlateable(capi.World, heldSlot.Itemstack)) return;

            DishwarePlacementState.PreviewRotation =
                ((DishwarePlacementState.PreviewRotation + System.Math.Sign(args.delta)) % 4 + 4) % 4;
            args.SetHandled(true);
        }
    }
}
