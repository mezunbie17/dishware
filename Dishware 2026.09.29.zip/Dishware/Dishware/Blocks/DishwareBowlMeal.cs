﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace Dishware.Blocks
{
    public class DishwareBowlMeal : BlockCookedContainer, IContainedMeshSource, IBlockMealContainer
    {
        private MealMeshCache meshCache;
        private Dictionary<string, AssetLocation> mealShapesByTemplate = new Dictionary<string, AssetLocation>();
        private Block mealTextureSourceBlock;
        private string MealMeshRefsCacheKey => this.Code.ToShortString() + "mealMeshRefs";
        private const float MaxFoodDropY = 0.15f;

        private Block GetMealTextureSourceBlock(ICoreClientAPI capi)
        {
            if (mealTextureSourceBlock == null)
            {
                mealTextureSourceBlock = capi.World.GetBlock(new AssetLocation("claypot-blue-cooked"));
            }
            return mealTextureSourceBlock;
        }
        public override void OnLoaded(ICoreAPI api)
        {
            base.OnLoaded(api);
            if (api is ICoreClientAPI capi)
            {
                this.meshCache = capi.ModLoader.GetModSystem<MealMeshCache>(true);
            }

            JsonObject mealShapesAttr = this.Attributes["dishwareMealShapes"];
            if (mealShapesAttr.Exists)
            {
                Dictionary<string, string> rawMap = mealShapesAttr.AsObject<Dictionary<string, string>>();
                if (rawMap != null)
                {
                    foreach (var pair in rawMap)
                    {
                        mealShapesByTemplate[pair.Key] = new AssetLocation(this.Code.Domain, pair.Value.ToLowerInvariant());
                    }
                }
            }
        }
        public new float GetQuantityServings(IWorldAccessor world, ItemStack byItemStack)
        {
            float result = base.GetQuantityServings(world, byItemStack);
            this.api.Logger.Notification("[Dishware] GetQuantityServings called, returning {0}", result);
            return result;
        }

        public new void SetQuantityServings(IWorldAccessor world, ItemStack byItemStack, float value)
        {
            this.api.Logger.Notification("[Dishware] SetQuantityServings called with value={0}", value);
            base.SetQuantityServings(world, byItemStack, value);
        }

        private bool HasValidMealData(IWorldAccessor world, ItemStack itemstack)
        {
            ItemStack[] contents = this.GetNonEmptyContents(world, itemstack);
            CookingRecipe recipe = this.GetCookingRecipe(world, itemstack);
            return contents != null && contents.Length > 0 && recipe != null;
        }
        public override bool OnContainedInteractStart(BlockEntityContainer be, ItemSlot slot, IPlayer byPlayer, BlockSelection blockSel)
        {
            return false;
        }

        private MeshData GenScaledMealMesh(ICoreClientAPI capi, ItemStack itemstack)
        {
            CookingRecipe debugRecipe = this.GetCookingRecipe(capi.World, itemstack);
            float debugServings = this.GetQuantityServings(capi.World, itemstack);
            ItemStack[] debugContents = this.GetNonEmptyContents(capi.World, itemstack);
            capi.Logger.Notification("[Dishware] Bowl render: recipe={0}, servings={1}, contentCount={2}",
                debugRecipe?.Code ?? "null", debugServings, debugContents?.Length ?? -1);
            try
            {
                CompositeShape shape = this.Shape;
                AssetLocation shapePath = shape.Base.Clone().WithPathPrefixOnce("shapes/").WithPathAppendixOnce(".json");
                Shape shapeBase = Vintagestory.API.Common.Shape.TryGet(capi, shapePath);

                MeshData containerMesh;
                capi.Tesselator.TesselateShape("meal", shapeBase, out containerMesh, capi.Tesselator.GetTextureSource(this, 0, false),
                    new Vec3f(shape.rotateX, shape.rotateY, shape.rotateZ), 0, 0, 0, null, null);

                CookingRecipe recipe = this.GetCookingRecipe(capi.World, itemstack);
                ItemStack[] contents = this.GetNonEmptyContents(capi.World, itemstack);

                MeshData foodMesh = GenFoodMesh(capi, recipe, contents);

                if (foodMesh != null)
                {
                    float servingCapacity = itemstack.Block.Attributes["servingCapacity"].AsFloat(1f);
                    float fillFraction = servingCapacity > 0f ? GameMath.Clamp(debugServings / servingCapacity, 0f, 1f) : 1f;
                    float dropY = (1f - fillFraction) * MaxFoodDropY;
                    foodMesh.Translate(0f, -dropY, 0f);
                    containerMesh.AddMeshData(foodMesh);
                }
                return containerMesh;
            }
            catch (Exception ex)
            {
                this.api.Logger.Error("[Dishware] GenScaledMealMesh threw: {0}", ex);
                return new MeshData(true);
            }
        }

        public override void OnBeforeRender(ICoreClientAPI capi, ItemStack itemstack, EnumItemRenderTarget target, ref ItemRenderInfo renderinfo)
        {
            if (!HasValidMealData(capi.World, itemstack)) return;

            if (!(capi.ObjectCache.TryGetValue(MealMeshRefsCacheKey, out object obj) && obj is Dictionary<string, MultiTextureMeshRef> dictionary))
            {
                dictionary = new Dictionary<string, MultiTextureMeshRef>();
                capi.ObjectCache[MealMeshRefsCacheKey] = dictionary;
            }

            string hashKey = this.meshCache.GetMealHashCode(itemstack, new Vec3f(0f, this.yoff / 16f, 0f), "").ToString()
                + "_servings" + this.GetQuantityServings(capi.World, itemstack);
            if (!dictionary.TryGetValue(hashKey, out MultiTextureMeshRef modelRef))
            {
                MeshData mesh = GenScaledMealMesh(capi, itemstack);
                modelRef = capi.Render.UploadMultiTextureMesh(mesh);
                dictionary[hashKey] = modelRef;
            }
            renderinfo.ModelRef = modelRef;
        }

        public override void OnUnloaded(ICoreAPI api)
        {
            base.OnUnloaded(api);
            if (!(api is ICoreClientAPI capi)) return;

            if (capi.ObjectCache.TryGetValue(MealMeshRefsCacheKey, out object obj) && obj is Dictionary<string, MultiTextureMeshRef> dictionary)
            {
                foreach (var kv in dictionary) kv.Value.Dispose();
                capi.ObjectCache.Remove(MealMeshRefsCacheKey);
            }
        }
        public override string GetMeshCacheKey(ItemSlot slot)
        {
            string baseKey = this.meshCache.GetMealHashCode(slot.Itemstack, new Vec3f(0f, this.yoff / 16f, 0f), "").ToString();
            float servings = this.GetQuantityServings(this.api.World, slot.Itemstack);
            return baseKey + "_servings" + servings;
        }

        public new MeshData GenMesh(ItemSlot slot, ITextureAtlasAPI targetAtlas, BlockPos forBlockPos)
        {
            if (!HasValidMealData(this.api.World, slot.Itemstack))
            {
                return new MeshData(true);
            }
            return GenScaledMealMesh(this.api as ICoreClientAPI, slot.Itemstack);
        }

        private MeshData GenFoodMesh(ICoreClientAPI capi, CookingRecipe recipe, ItemStack[] contentStacks)
        {
            bool rotten = MealMeshCache.ContentsRotten(contentStacks);

            string templateKey = rotten ? "rot" : recipe.Shape.Base.Path.Substring(recipe.Shape.Base.Path.LastIndexOf('/') + 1);

            if (!mealShapesByTemplate.TryGetValue(templateKey, out AssetLocation shapeLoc))
            {
                capi.Logger.Notification("[Dishware] GenFoodMesh: no shape found for template '{0}', falling back to vanilla", templateKey);
                return this.meshCache.GenMealMesh(recipe, contentStacks, null);
            }

            Shape shapeBase = Vintagestory.API.Common.Shape.TryGet(capi, shapeLoc.WithPathAppendixOnce(".json").WithPathPrefixOnce("shapes/"));
            if (shapeBase == null) return null;

            MealTextureSource texSource = new MealTextureSource(capi, GetMealTextureSourceBlock(capi));
            MeshData meshData = null;

            if (rotten)
            {
                capi.Tesselator.TesselateShape("mealpart", shapeBase, out meshData, texSource, null, 0, 0, 0, null, null);
                return meshData;
            }

            Dictionary<CookingRecipeIngredient, int> matchCounts = new Dictionary<CookingRecipeIngredient, int>();
            HashSet<string> seen = new HashSet<string>();

            for (int i = 0; i < contentStacks.Length; i++)
            {
                texSource.ForStack = contentStacks[i];

                CookingRecipeIngredient ingredient = recipe.GetIngrendientFor(contentStacks[i],
                    matchCounts.Where(kv => kv.Key.MaxQuantity <= kv.Value).Select(kv => kv.Key).ToArray());
                if (ingredient == null)
                {
                    ingredient = recipe.GetIngrendientFor(contentStacks[i], Array.Empty<CookingRecipeIngredient>());
                }
                else
                {
                    matchCounts.TryGetValue(ingredient, out int count);
                    matchCounts[ingredient] = count + 1;
                }

                if (ingredient == null) continue;

                CookingRecipeStack matchingStack = ingredient.GetMatchingStack(contentStacks[i]);
                if (matchingStack == null) continue;

                string shapeElement = matchingStack.ShapeElement;
                if (shapeElement != null && !shapeElement.EndsWith("*"))
                {
                    shapeElement += "/*";
                }
                string[] selectiveElements = shapeElement != null ? new[] { shapeElement } : null;
                capi.Logger.Notification("[Dishware] Ingredient '{0}' -> ShapeElement: {1}", contentStacks[i].GetName(), matchingStack.ShapeElement ?? "NULL (renders whole shape!)");
                texSource.customTextureMapping = matchingStack.TextureMapping;

                string dedupeKey = matchingStack.ShapeElement + (matchingStack.TextureMapping != null ? matchingStack.TextureMapping.ToString() : null);
                if (seen.Contains(dedupeKey)) continue;
                seen.Add(dedupeKey);

                MeshData piece;
                capi.Tesselator.TesselateShape("mealpart", shapeBase, out piece, texSource, null, 0, 0, 0, null, selectiveElements);
                if (meshData == null) meshData = piece;
                else meshData.AddMeshData(piece);
            }

            return meshData;
        }
    }
}