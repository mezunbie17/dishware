﻿using Dishware.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.Common;
using Vintagestory.GameContent;

namespace Dishware.Blocks
{
    public class BlockFilledPlate : BlockMeal, IContainedMeshSource, IContainedInteractable, IContainedCustomName, IDisplayableProps
    {

        protected override bool tryHeldBeginEatMeal(ItemSlot slot, EntityAgent byEntity, ref EnumHandHandling handHandling)
        {
            return false;
            //this simply disables eating from hand functionality
        }

        private bool[,]? validCellsMask;
        private Dictionary<string, FootprintSize> plateableMealRecipes = new Dictionary<string, FootprintSize>();
        private const int MaxInventoryMeshRefCacheSize = 1024;
        private Dictionary<string, MultiTextureMeshRef> inventoryMeshRefCache = new Dictionary<string, MultiTextureMeshRef>();
        private Queue<string> inventoryMeshRefCacheOrder = new Queue<string>();

        //builds plate mask and plateable meals whitelist
        public override void OnLoaded(ICoreAPI api)
        {
            base.OnLoaded(api);

            int gridSize = Attributes["dishwareGrid"]["size"].AsInt(32);
            float radius = Attributes["dishwareGrid"]["radius"].AsFloat(8f);
            string shape = Attributes["dishwareGrid"]["shape"].AsString("circle");

            validCellsMask = shape == "square"
                ? BuildSquareMask(gridSize, radius)
                : BuildCircularMask(gridSize, radius);

            AssetLocation configLoc = new AssetLocation("dishware", "config/plateable-meals.json");
            PlateableMealsConfig config = api.Assets.Get<PlateableMealsConfig>(configLoc);
            plateableMealRecipes = new Dictionary<string, FootprintSize>();
            foreach (var mealEntry in config?.plateableRecipes ?? Array.Empty<PlateableMealEntry>())
            {
                plateableMealRecipes[mealEntry.recipeCode] = new FootprintSize(mealEntry.footprintWidth, mealEntry.footprintHeight);
            }
        }

        public override TransitionState[]? UpdateAndGetTransitionStates(IWorldAccessor world, ItemSlot inslot)
        {
            ItemStack plateStack = inslot.Itemstack;
            if (plateStack == null) return null;

            List<PlatedFoodEntry> items = GetPlatedItems(world, plateStack);
            bool anyItemChanged = false;

            foreach (PlatedFoodEntry entry in items)
            {
                if (entry.MealData != null)
                {
                    ItemStack? rot = null;

                    foreach (ItemStack content in entry.MealData.ContentStacks)
                    {
                        if (content == null) continue;
                        bool wasRot = content.Collectible.Code.Path == "rot";

                        ItemSlot contentSlot = GetContentInDummySlot(inslot, content);
                        content.Collectible.UpdateAndGetTransitionStates(world, contentSlot);

                        if (contentSlot.Itemstack == null) rot ??= GetOneRot(world, content);
                        else if (!wasRot && contentSlot.Itemstack.Collectible.Code.Path == "rot") rot ??= contentSlot.Itemstack;
                    }

                    if (rot != null)
                    {
                        rot.StackSize = 1;
                        entry.MealData.ContentStacks = new ItemStack[] { rot };
                        anyItemChanged = true;
                    }
                    continue;
                }

                ItemStack before = entry.Stack;
                AssetLocation codeBefore = before.Collectible.Code;
                ItemSlot foodSlot = GetContentInDummySlot(inslot, before);
                before.Collectible.UpdateAndGetTransitionStates(world, foodSlot);

                ItemStack after = foodSlot.Itemstack ?? GetOneRot(world, before) ?? before;
                if (after.Collectible.Code == codeBefore) continue;

                after.StackSize = 1;
                entry.Stack = after;
                anyItemChanged = true;
            }

            SetPlatedItems(plateStack, items);

            if (anyItemChanged && world.Side == EnumAppSide.Server)
            {
                inslot.MarkDirty();
                BlockPos? pos = inslot.Inventory?.Pos;
                if (pos != null) world.BlockAccessor.GetBlockEntity(pos)?.MarkDirty(true);
            }

            return null;
        }

        private ItemStack? GetOneRot(IWorldAccessor world, ItemStack food)
        {
            TransitionableProperties[]? props = food.Collectible.GetTransitionableProperties(world, food, null);
            TransitionableProperties? perish = props?.FirstOrDefault(p => p.Type == EnumTransitionType.Perish);
            ItemStack? rot = perish?.TransitionedStack?.ResolvedItemstack?.Clone();
            if (rot != null) rot.StackSize = 1;
            return rot;
        }
        public override bool RequiresTransitionableTicking(IWorldAccessor world, ItemStack itemstack)
        {
            foreach (PlatedFoodEntry entry in GetPlatedItems(world, itemstack))
            {
                ItemStack[] foods = entry.MealData?.ContentStacks ?? new[] { entry.Stack };
                foreach (ItemStack food in foods)
                {
                    if (food != null && food.Collectible.RequiresTransitionableTicking(world, food)) return true;
                }
            }
            return false;
        }

        // lets vanilla meal and manual dishes see what's on plate
        public override ItemStack[] GetNonEmptyContents(IWorldAccessor world, ItemStack itemstack)
        {
            if (itemstack == null) return Array.Empty<ItemStack>();

            List<ItemStack> contents = new List<ItemStack>();
            foreach (PlatedFoodEntry entry in GetPlatedItems(world, itemstack))
            {
                if (entry.MealData != null) contents.AddRange(entry.MealData.ContentStacks.Where(s => s != null));
                else if (entry.Stack != null) contents.Add(entry.Stack);
            }
            return contents.ToArray();
        }

        // guards against plate wash crashing
        public override void OnGroundIdle(EntityItem entityItem)
        {
            if (GetNonEmptyContents(entityItem.World, entityItem.Itemstack).Length == 0) return;
            base.OnGroundIdle(entityItem);
        }

        // makes circular food placement grid
        public static bool[,] BuildCircularMask(int gridSize, float radiusInCells)
        {
            bool[,] mask = new bool[gridSize, gridSize];
            float center = (gridSize - 1) / 2f;

            for (int x = 0; x < gridSize; x++)
            {
                for (int z = 0; z < gridSize; z++)
                {
                    float dx = x - center;
                    float dz = z - center;
                    float distance = (float)Math.Sqrt(dx * dx + dz * dz);
                    mask[x, z] = distance <= radiusInCells;
                }
            }

            return mask;
        }

        //makes square food placement grid
        public static bool[,] BuildSquareMask(int gridSize, float halfSideInCells)
        {
            bool[,] mask = new bool[gridSize, gridSize];
            float center = (gridSize - 1) / 2f;

            for (int x = 0; x < gridSize; x++)
            {
                for (int z = 0; z < gridSize; z++)
                {
                    float dx = Math.Abs(x - center);
                    float dz = Math.Abs(z - center);
                    mask[x, z] = dx <= halfSideInCells && dz <= halfSideInCells;
                }
            }

            return mask;
        }

        //HitPositionToGridCell converts player's click position on plate grid into x,z value; called with blockSel.HitPosition
        public static (int x, int z) HitPositionToGridCell(Vec3d hitPosition, int gridSize)
        {
            float cellWidth = 1f / gridSize;
            int cellX = (int)Math.Floor(hitPosition.X / cellWidth);
            int cellZ = (int)Math.Floor(hitPosition.Z / cellWidth);
            cellX = Math.Min(cellX, gridSize - 1);
            cellZ = Math.Min(cellZ, gridSize - 1);
            return (cellX, cellZ);
        }

        //math for food rendering, takes food's position data and returns it as data relative to block
        public static FoodSize EntryToBlockSpace(PlatedFoodEntry entry, int gridSize)
        {
            float cellWidth = 1f / gridSize;
            float width = entry.Footprint.Width * cellWidth;
            float height = entry.Footprint.Height * cellWidth;
            float offsetX = entry.AnchorX * cellWidth;
            float offsetZ = entry.AnchorZ * cellWidth;

            return new FoodSize(width, height, offsetX, offsetZ);
        }

        public int GridSize => validCellsMask?.GetLength(0) ?? 32;


        private class DishwareTexSource : ITexPositionSource
        {
            private readonly ITextureAtlasAPI targetAtlas;
            private readonly CollectibleObject collectible;

            public DishwareTexSource(ITextureAtlasAPI targetAtlas, CollectibleObject collectible)
            {
                this.targetAtlas = targetAtlas;
                this.collectible = collectible;
            }
            public Size2i AtlasSize => targetAtlas.Size;
            public TextureAtlasPosition this[string textureCode]
            {
                get
                {
                    IDictionary<string, CompositeTexture> textures = null;
                    if (collectible is Block block)
                    {
                        textures = block.Textures;
                    }
                    else if (collectible is Item item)
                    {
                        textures = item.Textures;
                    }

                    if (textures == null || textures.Count == 0) return null;
                    CompositeTexture tex;
                    if (!textures.TryGetValue(textureCode, out tex))
                    {
                        tex = textures.Values.First();
                    }
                    int textureSubId;
                    TextureAtlasPosition texPos;
                    targetAtlas.GetOrInsertTexture(tex.Base, out textureSubId, out texPos);
                    return texPos;
                }
            }
        }

        //GenMesh gets the meshes of both the plate and the food items and combines them
        public new MeshData GenMesh(ItemSlot slot, ITextureAtlasAPI targetAtlas, BlockPos atBlockPos)
        {
            if (!(api is ICoreClientAPI coreClientAPI))
            {
                return null;
            }

            ItemStack stack = slot.Itemstack;
            IWorldAccessor world = api.World;
            int gridSize = validCellsMask.GetLength(0);

            List<PlatedFoodEntry> items = GetPlatedItems(world, stack);

            CompositeShape plateShape = this.Shape;
            AssetLocation plateShapeLoc = plateShape.Base.Clone().WithPathPrefixOnce("shapes/").WithPathAppendixOnce(".json");
            Shape realPlateShape = coreClientAPI.Assets.Get<Shape>(plateShapeLoc);
            MeshData baseMesh;
            ITexPositionSource plateTexSource = new DishwareTexSource(targetAtlas, this);
            coreClientAPI.Tesselator.TesselateShape(this.Code.ToShortString(), realPlateShape, out baseMesh, plateTexSource);



            foreach (var entry in items)
            {
                if (entry.MealData != null)
                {
                    CookingRecipe recipe = GetCookingRecipeAnySource(entry.MealData.RecipeCode);
                    if (recipe == null) continue;

                    MealMeshCache mealMeshCache = coreClientAPI.ModLoader.GetModSystem<MealMeshCache>(true);
                    MeshData mealMesh = mealMeshCache.GenFoodMixMesh(entry.MealData.ContentStacks, recipe, null);

                    if (mealMesh != null)
                    {
                        float mMinX = 0, mMaxX = 0, mMinY = 0, mMaxY = 0, mMinZ = 0, mMaxZ = 0;
                        for (int i = 0; i < mealMesh.VerticesCount; i++)
                        {
                            float x = mealMesh.xyz[i * 3];
                            float y = mealMesh.xyz[i * 3 + 1];
                            float z = mealMesh.xyz[i * 3 + 2];

                            if (i == 0)
                            {
                                mMinX = mMaxX = x;
                                mMinY = mMaxY = y;
                                mMinZ = mMaxZ = z;
                            }
                            else
                            {
                                if (x < mMinX) mMinX = x;
                                if (x > mMaxX) mMaxX = x;
                                if (y < mMinY) mMinY = y;
                                if (y > mMaxY) mMaxY = y;
                                if (z < mMinZ) mMinZ = z;
                                if (z > mMaxZ) mMaxZ = z;
                            }
                        }

                        FoodSize mealBlockSpace = EntryToBlockSpace(entry, gridSize);
                        float mealCenterX = mealBlockSpace.OffsetX + mealBlockSpace.Width / 2f;
                        float mealCenterZ = mealBlockSpace.OffsetZ + mealBlockSpace.Height / 2f;

                        float mealNatX = mMaxX - mMinX;
                        float mealNatZ = mMaxZ - mMinZ;
                        if (mealNatX > 0 && mealNatZ > 0)
                        {
                            float mealRealX = mealBlockSpace.Width / mealNatX;
                            float mealRealZ = mealBlockSpace.Height / mealNatZ;
                            float mealSmallRatio = Math.Min(mealRealX, mealRealZ);

                            Vec3f mealOrigin = new Vec3f((mMinX + mMaxX) / 2f, mMinY, (mMinZ + mMaxZ) / 2f);
                            mealMesh = mealMesh.Scale(mealOrigin, mealSmallRatio, mealSmallRatio, mealSmallRatio);

                            mealMesh.Translate(mealCenterX - mealOrigin.X, 0.046875f - mMinY, mealCenterZ - mealOrigin.Z);
                            baseMesh.AddMeshData(mealMesh);
                        }
                    }

                    continue;
                }

                CollectibleObject platingSource = GetPlatingSource(entry.Stack);
                FoodSize blockSpace = EntryToBlockSpace(entry, gridSize);
                MeshData foodMesh;
                if (entry.Stack.Collectible is BlockPie)
                {
                    MealMeshCache pieMeshCache = coreClientAPI.ModLoader.GetModSystem<MealMeshCache>(true);
                    foodMesh = pieMeshCache.GetPieMesh(entry.Stack)?.Clone();
                    if (foodMesh == null) continue;
                }
                else
                {
                    foodMesh = TryGenIngredientMesh(entry.Stack, targetAtlas, coreClientAPI);
                    if (foodMesh == null)
                    {
                        CompositeShape entryShape;

                        if (entry.Stack.Class == EnumItemClass.Item)
                        {
                            entryShape = entry.Stack.Item.Shape;
                        }
                        else
                        {
                            Block entryBlock = entry.Stack.Block;
                            bool useInvShape = entryBlock.ShapeInventory != null
                                && (entryBlock.Attributes?["dishwareUseInventoryShape"]?.AsBool(false) ?? false);
                            entryShape = useInvShape ? entryBlock.ShapeInventory : entryBlock.Shape;
                        }

                        if (entryShape == null)
                        {
                            continue;
                        }
                        AssetLocation entryShapeLoc = entryShape.Base.Clone().WithPathPrefixOnce("shapes/").WithPathAppendixOnce(".json");
                        Shape realShape = coreClientAPI.Assets.Get<Shape>(entryShapeLoc);
                        ITexPositionSource foodTexSource = new DishwareTexSource(targetAtlas, entry.Stack.Collectible);
                        coreClientAPI.Tesselator.TesselateShape(entry.Stack.Collectible.Code.ToShortString(), realShape, out foodMesh, foodTexSource);
                    }
                }
                if (foodMesh.VerticesCount == 0) continue;

                float preMinX = 0, preMaxX = 0, preMinY = 0, preMaxY = 0, preMinZ = 0, preMaxZ = 0;
                for (int i = 0; i < foodMesh.VerticesCount; i++)
                {
                    float px = foodMesh.xyz[i * 3];
                    float py = foodMesh.xyz[i * 3 + 1];
                    float pz = foodMesh.xyz[i * 3 + 2];

                    if (i == 0)
                    {
                        preMinX = preMaxX = px;
                        preMinY = preMaxY = py;
                        preMinZ = preMaxZ = pz;
                    }
                    else
                    {
                        if (px < preMinX) preMinX = px;
                        if (px > preMaxX) preMaxX = px;
                        if (py < preMinY) preMinY = py;
                        if (py > preMaxY) preMaxY = py;
                        if (pz < preMinZ) preMinZ = pz;
                        if (pz > preMaxZ) preMaxZ = pz;
                    }
                }
                Vec3f rotationPivot = new Vec3f(
                    (preMinX + preMaxX) / 2f,
                    (preMinY + preMaxY) / 2f,
                    (preMinZ + preMaxZ) / 2f
                );

                float rotXDeg = platingSource.Attributes?["dishwareMeshRotationX"]?.AsFloat(0f) ?? 0f;
                if (rotXDeg != 0f)
                {
                    foodMesh = foodMesh.Rotate(rotationPivot, rotXDeg * (float)(Math.PI / 180.0), 0f, 0f);
                }
                float rotZDeg = platingSource.Attributes?["dishwareMeshRotationZ"]?.AsFloat(0f) ?? 0f;
                if (rotZDeg != 0f)
                {
                    foodMesh = foodMesh.Rotate(rotationPivot, 0f, 0f, rotZDeg * (float)(Math.PI / 180.0));
                }

                if (entry.RotationY != 0)
                {
                    float rotYDeg = entry.RotationY * 90f;
                    foodMesh = foodMesh.Rotate(rotationPivot, 0f, rotYDeg * (float)(Math.PI / 180.0), 0f);
                }

                float minX = 0, maxX = 0, minZ = 0, maxZ = 0;
                List<float> yValues = new List<float>(foodMesh.VerticesCount);
                for (int i = 0; i < foodMesh.VerticesCount; i++)
                {
                    float x = foodMesh.xyz[i * 3];
                    float y = foodMesh.xyz[i * 3 + 1];
                    float z = foodMesh.xyz[i * 3 + 2];
                    yValues.Add(y);

                    if (i == 0)
                    {
                        minX = x;
                        maxX = x;
                        minZ = z;
                        maxZ = z;
                    }
                    else
                    {
                        if (x < minX) minX = x;
                        if (x > maxX) maxX = x;
                        if (z < minZ) minZ = z;
                        if (z > maxZ) maxZ = z;
                    }
                }
                yValues.Sort();
                float minY = yValues[(int)(yValues.Count * 0.05f)];

                float natX = maxX - minX;
                float natZ = maxZ - minZ;
                if (natX == 0 || natZ == 0) continue;
                float realX = blockSpace.Width / natX;
                float realZ = blockSpace.Height / natZ;
                float smallRatio = Math.Min(realX, realZ);
                float scaleMultiplier = platingSource.Attributes?["dishwareScaleMultiplier"]?.AsFloat(1f) ?? 1f;
                smallRatio *= scaleMultiplier;
                Vec3f origin = new Vec3f(
                    (minX + maxX) / 2,
                    minY,
                    (minZ + maxZ) / 2
                );
                foodMesh = foodMesh.Scale(origin, smallRatio, smallRatio, smallRatio);

                float footprintCenterX = blockSpace.OffsetX + blockSpace.Width / 2f;
                float footprintCenterZ = blockSpace.OffsetZ + blockSpace.Height / 2f;
                var offsetAttr = platingSource.Attributes?["dishwarePositionOffset"];
                (float offsetX, float offsetZ) posOffset = (offsetAttr != null && offsetAttr.Exists)
                    ? (offsetAttr["x"].AsFloat(0f), offsetAttr["z"].AsFloat(0f))
                    : (0f, 0f);
                if (entry.RotationY != 0)
                {
                    float offsetTheta = entry.RotationY * 90f * (float)(Math.PI / 180.0);
                    float cosO = (float)Math.Cos(offsetTheta);
                    float sinO = (float)Math.Sin(offsetTheta);
                    posOffset = (
                        posOffset.offsetX * cosO + posOffset.offsetZ * sinO,
                        -posOffset.offsetX * sinO + posOffset.offsetZ * cosO
                    );
                }

                foodMesh = foodMesh.Translate(footprintCenterX - origin.X + posOffset.offsetX, 0.046875f - minY, footprintCenterZ - origin.Z + posOffset.offsetZ);

                baseMesh.AddMeshData(foodMesh);

            }

            return baseMesh;
        }

        //produces a string that uniquely represents this plate's current contents
        public new string GetMeshCacheKey(ItemSlot slot)
        {

            ItemStack stack = slot.Itemstack;
            IWorldAccessor world = api.World;

            List<PlatedFoodEntry> items = GetPlatedItems(world, stack);
            List<string> entryKeys = new List<string>();
            foreach (var entry in items)
            {
                if (entry.MealData != null)
                {
                    string contentsKey = string.Join(",", entry.MealData.ContentStacks.Select(s => s?.Collectible?.Code.ToString() ?? "null"));
                    entryKeys.Add($"meal:{entry.MealData.RecipeCode},{contentsKey},{entry.AnchorX},{entry.AnchorZ},{entry.RotationY}");
                }
                else
                {
                    string pieKey = "";
                    if (entry.Stack.Collectible is BlockPie pie)
                    {
                        string fillings = string.Join(",", pie.GetNonEmptyContents(world, entry.Stack).Select(s => s.Collectible.Code.ToString()));
                        pieKey = $",{fillings},{entry.Stack.Attributes.GetString("topCrustType")}";
                    }
                    string ingKey = entry.Stack.Attributes?["madeWith"] is StringArrayAttribute madeWith ? "," + string.Join(",", madeWith.value) : "";
                    entryKeys.Add($"{entry.Stack.Collectible.Code},{entry.AnchorX},{entry.AnchorZ},{entry.RotationY}{pieKey}{ingKey}");
                }
            }
            return this.Code.ToShortString() + "|" + string.Join("|", entryKeys);
        }

        //overrides cabinet stacking for plates that have food on them
        public DisplayableAttributes? GetDisplayableProps(ItemSlot inSlot, string displayType)
        {
            ItemStack? stack = inSlot.Itemstack;
            if (stack == null) return null;

            if (stack.Attributes.GetInt("platedItemCount") == 0) return null;

            DisplayableAttributes? props = Attributes?["displayable"][displayType].AsObject<DisplayableAttributes>(null);
            if (props == null) return null;

            props.Behavior = EnumDisplayableBehavior.Default;
            props.Category = "dishware-plate-withfood";
            return props;
        }

        //creates plate+food mesh for inventory icon
        public override void OnBeforeRender(ICoreClientAPI capi, ItemStack itemstack, EnumItemRenderTarget target, ref ItemRenderInfo renderinfo)
        {
            ItemSlot dummySlot = new DummySlot(itemstack);
            string cacheKey = GetMeshCacheKey(dummySlot);

            if (!inventoryMeshRefCache.TryGetValue(cacheKey, out MultiTextureMeshRef meshRef))
            {
                MeshData meshData = GenMesh(dummySlot, capi.BlockTextureAtlas, null);

                meshRef = capi.Render.UploadMultiTextureMesh(meshData);

                inventoryMeshRefCache[cacheKey] = meshRef;
                inventoryMeshRefCacheOrder.Enqueue(cacheKey);

                if (inventoryMeshRefCacheOrder.Count > MaxInventoryMeshRefCacheSize)
                {
                    string oldestKey = inventoryMeshRefCacheOrder.Dequeue();
                    if (inventoryMeshRefCache.TryGetValue(oldestKey, out MultiTextureMeshRef oldestRef))
                    {
                        oldestRef.Dispose();
                        inventoryMeshRefCache.Remove(oldestKey);
                    }
                }
            }

            renderinfo.ModelRef = meshRef;
        }

        //clears mesh cache
        public override void OnUnloaded(ICoreAPI api)
        {
            base.OnUnloaded(api);
            foreach (MultiTextureMeshRef meshRef in inventoryMeshRefCache.Values)
            {
                meshRef.Dispose();
            }
            inventoryMeshRefCache.Clear();
            inventoryMeshRefCacheOrder.Clear();
        }

        //CanPlaceFootprint determines if food will fit given its size and space on the plate
        public bool CanPlaceFootprint(int anchorX, int anchorZ, FootprintSize footprint, ItemStack?[,] occupancy)
        {
            if (validCellsMask == null) return false; // mask wasn't built yet — shouldn't normally happen

            int gridSize = validCellsMask.GetLength(0);

            for (int x = anchorX; x < anchorX + footprint.Width; x++)
            {
                for (int z = anchorZ; z < anchorZ + footprint.Height; z++)
                {
                    if (x < 0 || x >= gridSize || z < 0 || z >= gridSize) return false;
                    if (!validCellsMask[x, z]) return false;
                    if (occupancy[x, z] != null) return false;
                }
            }

            return true;
        }

        //getplateditems decodes a plate itemstack into a list<platedfoodentry> - what food is where
        public List<PlatedFoodEntry> GetPlatedItems(IWorldAccessor world, ItemStack stack)
        {
            var items = new List<PlatedFoodEntry>();
            int count = stack.Attributes.GetInt("platedItemCount");

            for (int i = 0; i < count; i++)
            {
                string recipeCode = stack.Attributes.GetString($"platedItemMealRecipeCode{i}", null);

                PlatedFoodEntry entry;
                if (recipeCode != null)
                {
                    float servings = stack.Attributes.GetFloat($"platedItemMealServings{i}", 1f);
                    int contentCount = stack.Attributes.GetInt($"platedItemMealContentCount{i}");
                    ItemStack[] contentStacks = new ItemStack[contentCount];
                    bool anyUnresolved = false;
                    for (int j = 0; j < contentCount; j++)
                    {
                        ItemStack contentStack = stack.Attributes.GetItemstack($"platedItemMealContent{i}_{j}");
                        if (contentStack != null && (!contentStack.ResolveBlockOrItem(world) || contentStack.Collectible.IsMissing)) anyUnresolved = true;
                        contentStacks[j] = contentStack;
                    }
                    if (anyUnresolved) continue;

                    entry = new PlatedFoodEntry
                    {
                        MealData = new PlatedMealData
                        {
                            RecipeCode = recipeCode,
                            ContentStacks = contentStacks,
                            QuantityServings = servings
                        }
                    };
                }
                else
                {
                    ItemStack foodStack = stack.Attributes.GetItemstack($"platedItem{i}");
                    if (foodStack == null || !foodStack.ResolveBlockOrItem(world) || foodStack.Collectible.IsMissing) continue;
                    entry = new PlatedFoodEntry { Stack = foodStack };
                }

                entry.AnchorX = stack.Attributes.GetInt($"platedItemAnchorX{i}");
                entry.AnchorZ = stack.Attributes.GetInt($"platedItemAnchorZ{i}");
                entry.Footprint = new FootprintSize(
                    stack.Attributes.GetInt($"platedItemFootW{i}", 1),
                    stack.Attributes.GetInt($"platedItemFootH{i}", 1)
                );
                entry.RotationY = stack.Attributes.GetInt($"platedItemRotationY{i}", 0);

                items.Add(entry);
            }

            return items;
        }

        //setplateditems turns a list<platedfoodentry> into a plate itemstack which is saved
        public void SetPlatedItems(ItemStack stack, List<PlatedFoodEntry> items)
        {
            var oldKeys = stack.Attributes.Select(a => a.Key).Where(k => k.StartsWith("platedItem")).ToList();
            foreach (string key in oldKeys) stack.Attributes.RemoveAttribute(key);

            if (items.Count == 0) return;

            stack.Attributes.SetInt("platedItemCount", items.Count);

            for (int i = 0; i < items.Count; i++)
            {
                var entry = items[i];

                if (entry.MealData != null)
                {
                    stack.Attributes.SetString($"platedItemMealRecipeCode{i}", entry.MealData.RecipeCode);
                    stack.Attributes.SetFloat($"platedItemMealServings{i}", entry.MealData.QuantityServings);
                    stack.Attributes.SetInt($"platedItemMealContentCount{i}", entry.MealData.ContentStacks.Length);
                    for (int j = 0; j < entry.MealData.ContentStacks.Length; j++)
                    {
                        stack.Attributes.SetItemstack($"platedItemMealContent{i}_{j}", entry.MealData.ContentStacks[j]);
                    }
                }
                else
                {
                    stack.Attributes.SetItemstack($"platedItem{i}", entry.Stack);
                }

                stack.Attributes.SetInt($"platedItemAnchorX{i}", entry.AnchorX);
                stack.Attributes.SetInt($"platedItemAnchorZ{i}", entry.AnchorZ);
                stack.Attributes.SetInt($"platedItemFootW{i}", entry.Footprint.Width);
                stack.Attributes.SetInt($"platedItemFootH{i}", entry.Footprint.Height);
                stack.Attributes.SetInt($"platedItemRotationY{i}", entry.RotationY);
            }
        }
        // Rebuilds the occupancy grid on demand from PlatedItems — used by CanPlaceFootprint
        public ItemStack?[,] BuildOccupancyGrid(int gridSize, List<PlatedFoodEntry> items)
        {
            ItemStack?[,] grid = new ItemStack?[gridSize, gridSize];

            foreach (var entry in items)
            {
                ItemStack occupancyMarker = entry.Stack ?? entry.MealData?.ContentStacks?.FirstOrDefault(s => s != null);

                for (int x = entry.AnchorX; x < entry.AnchorX + entry.Footprint.Width; x++)
                {
                    for (int z = entry.AnchorZ; z < entry.AnchorZ + entry.Footprint.Height; z++)
                    {
                        if (x >= 0 && x < gridSize && z >= 0 && z < gridSize)
                        {
                            grid[x, z] = occupancyMarker;
                        }
                    }
                }
            }
            return grid;
        }

        // GetEntryAt determines which plate list occupies a given cell
        public PlatedFoodEntry? GetEntryAt(int x, int z, List<PlatedFoodEntry> items)
        {
            return items.FirstOrDefault(entry =>
                x >= entry.AnchorX && x < entry.AnchorX + entry.Footprint.Width &&
                z >= entry.AnchorZ && z < entry.AnchorZ + entry.Footprint.Height);
        }

        //AddEntry adds an entry to a plate list
        public void AddEntry(PlatedFoodEntry entry, List<PlatedFoodEntry> items, ItemStack stack)
        {
            items.Add(entry);
            SetPlatedItems(stack, items);
            SetQuantityServings(api.World, stack, 1f);
        }

        //RemoveEntry removes an entry from a plate list
        public void RemoveEntry(PlatedFoodEntry entry, List<PlatedFoodEntry> items, ItemStack stack)
        {
            items.Remove(entry);
            SetPlatedItems(stack, items);
            SetQuantityServings(api.World, stack, items.Count > 0 ? 1f : 0f);
        }

        //checks if food can be plated or not
        public virtual bool IsPlateable(IWorldAccessor world, ItemStack stack)
        {
            var overrideAttr = stack.Collectible.Attributes?["dishwareUnplateable"];
            if (stack.Collectible is BlockPie)
            {
                return stack.Attributes.GetAsInt("pieSize") == 1
                    && stack.Collectible.Variant["state"] != "raw";
            }
            if (overrideAttr != null && overrideAttr.Exists && overrideAttr.AsBool(false))
            {
                return false;
            }

            var attr = stack.Collectible.GetNutritionProperties(world, stack, null);
            return attr != null;


        }

        //footprint size records a piece of food's size, sets default
        public virtual FootprintSize GetFootprint(ItemStack stack)
        {
            var attr = GetPlatingSource(stack).Attributes?["dishwareFootprint"];
            if (attr == null || !attr.Exists) return new FootprintSize(8, 8);

            int width = attr["width"].AsInt(2);
            int height = attr["height"].AsInt(2);
            return new FootprintSize(width, height);
        }

        //for foods drawn from ingredients
        private CollectibleObject GetPlatingSource(ItemStack stack)
        {
            if (!(stack.Collectible.Attributes?["dishwarePlatingFromIngredient"]?.AsBool(false) ?? false)) return stack.Collectible;
            JsonObject renderIngs = stack.Collectible.Attributes?["renderIngredients"];
            if (renderIngs == null || !renderIngs.Exists) return stack.Collectible;
            if (!(stack.Attributes?["madeWith"] is StringArrayAttribute madeWith)) return stack.Collectible;

            foreach (string code in madeWith.value)
            {
                if (!renderIngs[code].Exists) continue;
                AssetLocation loc = new AssetLocation(code);
                CollectibleObject ingredient = (CollectibleObject)api.World.GetBlock(loc) ?? api.World.GetItem(loc);
                if (ingredient != null) return ingredient;
            }
            return stack.Collectible;
        }

        //returns mesh of ingredient-rendered food
        private MeshData TryGenIngredientMesh(ItemStack stack, ITextureAtlasAPI targetAtlas, ICoreClientAPI capi)
        {
            if (stack.Collectible.Attributes?["renderIngredients"]?.Exists != true) return null;
            if (!(stack.Attributes?["madeWith"] is StringArrayAttribute madeWith) || madeWith.value.Length == 0) return null;

            //reflection so Dishware needs no reference to ACA
            var genMesh = stack.Collectible.GetType().GetMethod("GenMesh",
                new[] { typeof(ITextureAtlasAPI), typeof(string[]), typeof(Vec3f), typeof(ITesselatorAPI) });
            if (genMesh == null) return null;

            return genMesh.Invoke(stack.Collectible, new object[] { targetAtlas, madeWith.value, null, capi.Tesselator }) as MeshData;
        }

        //looks up the footprint for a plated meal serving, keyed on recipe code rather than an item stack
        public virtual FootprintSize GetMealFootprint(string recipeCode)
        {
            if (plateableMealRecipes.TryGetValue(recipeCode, out var footprint))
            {
                return footprint;
            }

            return new FootprintSize(4, 4);
        }
        
        //checks whether a given recipe code is on the meal-plating whitelist
        public bool IsMealPlateable(string recipeCode)
        {
            return recipeCode != null && plateableMealRecipes.ContainsKey(recipeCode);
        }

        //corrected hit position when placing food
        private Vec3d GetCorrectedHitPosition(BlockEntityContainer be, Vec3d hitPosition)
        {
            if (be is not BlockEntityGroundStorage beg) return hitPosition;

            float cos = (float)Math.Cos(beg.MeshAngle);
            float sin = (float)Math.Sin(beg.MeshAngle);

            double hx = hitPosition.X - 0.5;
            double hz = hitPosition.Z - 0.5;

            return new Vec3d(hx * cos - hz * sin + 0.5, hitPosition.Y, hx * sin + hz * cos + 0.5);
        }

        //OnContainedStart handles everything that happens when you first interact with a plate, including full button logic tree
        public new bool OnContainedInteractStart(BlockEntityContainer be, ItemSlot slot, IPlayer byPlayer, BlockSelection blockSel)
        {
            if (be is not BlockEntityGroundStorage) return false;
            ItemStack stack = slot.Itemstack;
            IWorldAccessor world = api.World;
            Vec3d hitPosition = GetCorrectedHitPosition(be, blockSel.HitPosition);
            int gridSize = validCellsMask.GetLength(0);

            List<PlatedFoodEntry> items = GetPlatedItems(world, stack);
            var (cellX, cellZ) = HitPositionToGridCell(hitPosition, gridSize);
            PlatedFoodEntry? entry = GetEntryAt(cellX, cellZ, items);
            ItemStack heldStack = byPlayer.InventoryManager.ActiveHotbarSlot.Itemstack;

            if (byPlayer.Entity.Controls.ShiftKey)
            {
                if (byPlayer.InventoryManager.ActiveHotbarSlot.Empty)
                {
                    if (entry != null)
                    {
                        if (entry.MealData != null)
                        {
                            return false;
                        }

                        RemoveEntry(entry, items, stack);
                        if (!byPlayer.InventoryManager.TryGiveItemstack(entry.Stack, true))
                        {
                            world.SpawnItemEntity(entry.Stack, be.Pos);
                        }
                        be.MarkDirty(true);
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    if (entry != null)
                    {
                        if (entry.MealData != null)
                        {
                            var heldAttrs = heldStack.Collectible.Attributes;
                            bool isEmptyMealContainer = heldAttrs != null && heldAttrs.IsTrue("mealContainer")
                                && heldStack.Attributes.GetString("recipeCode", null) == null;

                            if (isEmptyMealContainer)
                            {
                                string mealBlockCode = heldAttrs["mealBlockCode"].AsString(null);
                                Block mealBlock = mealBlockCode != null ? world.GetBlock(new AssetLocation(mealBlockCode)) : null;

                                if (mealBlock is BlockMeal targetMealBlock)
                                {
                                    ItemStack filledBowl = new ItemStack(targetMealBlock, 1);
                                    targetMealBlock.SetContents(entry.MealData.RecipeCode, filledBowl, entry.MealData.ContentStacks, entry.MealData.QuantityServings);

                                    if (byPlayer.InventoryManager.ActiveHotbarSlot.StackSize > 1)
                                    {
                                        byPlayer.InventoryManager.ActiveHotbarSlot.TakeOut(1);
                                        if (!byPlayer.InventoryManager.TryGiveItemstack(filledBowl, true))
                                        {
                                            world.SpawnItemEntity(filledBowl, byPlayer.Entity.Pos.XYZ);
                                        }
                                    }
                                    else
                                    {
                                        byPlayer.InventoryManager.ActiveHotbarSlot.Itemstack = filledBowl;
                                    }
                                    byPlayer.InventoryManager.ActiveHotbarSlot.MarkDirty();

                                    RemoveEntry(entry, items, stack);
                                    be.MarkDirty(true);
                                    return true;
                                }
                            }
                        }

                        else if (entry.Stack.Collectible.Equals(entry.Stack, heldStack, GlobalConstants.IgnoredStackAttributes))
                        {
                            var mergeOp = new ItemStackMergeOperation(world, EnumMouseButton.Right, (EnumModifierKey)0, EnumMergePriority.DirectMerge, entry.Stack.StackSize);
                            mergeOp.SourceSlot = new DummySlot(entry.Stack);
                            mergeOp.SinkSlot = new DummySlot(heldStack);
                            heldStack.Collectible.TryMergeStacks(mergeOp);

                            if (mergeOp.MovedQuantity > 0)
                            {
                                byPlayer.InventoryManager.ActiveHotbarSlot.Itemstack = mergeOp.SinkSlot.Itemstack;
                                byPlayer.InventoryManager.ActiveHotbarSlot.MarkDirty();

                                if (mergeOp.SourceSlot.Itemstack == null)
                                {
                                    RemoveEntry(entry, items, stack);
                                }
                                else
                                {
                                    entry.Stack = mergeOp.SourceSlot.Itemstack;
                                    SetPlatedItems(stack, items);
                                }
                                be.MarkDirty(true);
                            }

                            return true;
                        }

                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            else
            {
                if (byPlayer.InventoryManager.ActiveHotbarSlot.Empty)
                {
                    if (entry != null)
                    {
                        ItemStack targetStack = entry.MealData != null ? BuildTempMealStack(entry.MealData) : entry.Stack;
                        if (targetStack == null) return true;

                        DummySlot dummySlot = new DummySlot(targetStack);
                        EnumHandHandling handling = EnumHandHandling.NotHandled;
                        targetStack.Collectible.OnHeldInteractStart(dummySlot, byPlayer.Entity, blockSel, null, true, ref handling);

                        if (handling == EnumHandHandling.PreventDefault)
                        {
                            world.RegisterCallback(delegate (float dt)
                            {
                                byPlayer.Entity.PlayEntitySound("eat", byPlayer);
                            }, 500);
                        }

                        return handling == EnumHandHandling.PreventDefault;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    if (entry != null)
                    {
                        return true;
                    }
                    else
                    {

                        if (heldStack.Collectible is BlockMeal meal && meal is not BlockFilledPlate && meal is not BlockPie)
                        {
                            string recipeCode = meal.GetRecipeCode(world, heldStack);
                            if (recipeCode != null && plateableMealRecipes.ContainsKey(recipeCode))
                            {
                                ItemStack[] contentStacks = meal.GetNonEmptyContents(world, heldStack);
                                FootprintSize mealFootprint = GetMealFootprint(recipeCode);

                                ItemStack?[,] occupancy = BuildOccupancyGrid(gridSize, items);
                                bool canPlace = CanPlaceFootprint(cellX, cellZ, mealFootprint, occupancy);

                                if (canPlace)
                                {
                                    AddEntry(new PlatedFoodEntry
                                    {
                                        MealData = new PlatedMealData
                                        {
                                            RecipeCode = recipeCode,
                                            ContentStacks = contentStacks,
                                            QuantityServings = 1f
                                        },
                                        AnchorX = cellX,
                                        AnchorZ = cellZ,
                                        Footprint = mealFootprint,
                                    }, items, stack);

                                    string emptiedCode = heldStack.Collectible.Attributes?["eatenBlock"]?.AsString(null);
                                    if (emptiedCode != null)
                                    {
                                        Block emptyBlock = world.GetBlock(new AssetLocation(emptiedCode));
                                        if (emptyBlock != null)
                                        {
                                            ItemStack emptyStack = new ItemStack(emptyBlock, 1);
                                            if (byPlayer.InventoryManager.ActiveHotbarSlot.StackSize > 1)
                                            {
                                                byPlayer.InventoryManager.ActiveHotbarSlot.TakeOut(1);
                                                if (!byPlayer.InventoryManager.TryGiveItemstack(emptyStack, true))
                                                {
                                                    world.SpawnItemEntity(emptyStack, byPlayer.Entity.Pos.XYZ);
                                                }
                                            }
                                            else
                                            {
                                                byPlayer.InventoryManager.ActiveHotbarSlot.Itemstack = emptyStack;
                                            }
                                            byPlayer.InventoryManager.ActiveHotbarSlot.MarkDirty();
                                        }
                                    }

                                    be.MarkDirty(true);
                                }

                                return true;
                            }
                        }
                        else if (heldStack.Collectible is BlockCookedContainerBase potContainer)
                        {
                            string recipeCode = potContainer.GetRecipeCode(world, heldStack);
                            if (recipeCode != null && plateableMealRecipes.ContainsKey(recipeCode))
                            {
                                float potServings = potContainer.GetQuantityServings(world, heldStack);
                                if (potServings > 0f)
                                {
                                    ItemStack[] contentStacks = potContainer.GetNonEmptyContents(world, heldStack);
                                    FootprintSize mealFootprint = GetMealFootprint(recipeCode);

                                    ItemStack?[,] occupancy = BuildOccupancyGrid(gridSize, items);
                                    bool canPlace = CanPlaceFootprint(cellX, cellZ, mealFootprint, occupancy);

                                    if (canPlace)
                                    {
                                        AddEntry(new PlatedFoodEntry
                                        {
                                            MealData = new PlatedMealData
                                            {
                                                RecipeCode = recipeCode,
                                                ContentStacks = contentStacks,
                                                QuantityServings = 1f
                                            },
                                            AnchorX = cellX,
                                            AnchorZ = cellZ,
                                            Footprint = mealFootprint,
                                        }, items, stack);

                                        potContainer.SetQuantityServings(world, heldStack, potServings - 1f);

                                        DummySlot potSlot = new DummySlot(heldStack);
                                        heldStack.Collectible.UpdateAndGetTransitionStates(world, potSlot);
                                        byPlayer.InventoryManager.ActiveHotbarSlot.Itemstack = potSlot.Itemstack;
                                        byPlayer.InventoryManager.ActiveHotbarSlot.MarkDirty();

                                        be.MarkDirty(true);
                                    }
                                }
                                return true;
                            }
                        }

                        if (IsPlateable(world, heldStack))
                        {
                            int rotationY = DishwarePlacementState.PreviewRotation;
                            FootprintSize baseFootprint = GetFootprint(heldStack);
                            FootprintSize footprint = (rotationY % 2 == 1)
                                ? new FootprintSize(baseFootprint.Height, baseFootprint.Width)
                                : baseFootprint;
                            ItemStack?[,] occupancy = BuildOccupancyGrid(gridSize, items);
                            bool canPlace = CanPlaceFootprint(cellX, cellZ, footprint, occupancy);
                            ItemStack platedStack = heldStack.Clone();
                            platedStack.StackSize = 1;
                            if (CanPlaceFootprint(cellX, cellZ, footprint, occupancy))
                            {
                                AddEntry(new PlatedFoodEntry
                                {
                                    Stack = platedStack,
                                    AnchorX = cellX,
                                    AnchorZ = cellZ,
                                    Footprint = footprint,
                                    RotationY = rotationY,
                                }, items, stack);
                                byPlayer.InventoryManager.ActiveHotbarSlot.TakeOut(1);
                                byPlayer.InventoryManager.ActiveHotbarSlot.MarkDirty();
                                be.MarkDirty(true);
                            }
                            return true;
                        }
                        else
                        {
                            return true;
                        }
                    }
                }
            }
        }

        //OnContainedInteractStep is the middle bit of plate interaction
        public new bool OnContainedInteractStep(float secondsUsed, BlockEntityContainer be, ItemSlot slot, IPlayer byPlayer, BlockSelection blockSel)
        {
            ItemStack stack = slot.Itemstack;
            IWorldAccessor world = api.World;
            Vec3d hitPosition = GetCorrectedHitPosition(be, blockSel.HitPosition);
            int gridSize = validCellsMask.GetLength(0);

            List<PlatedFoodEntry> items = GetPlatedItems(world, stack);
            var (cellX, cellZ) = HitPositionToGridCell(hitPosition, gridSize);
            PlatedFoodEntry? entry = GetEntryAt(cellX, cellZ, items);

            if (entry == null) return false;
            else
            {
                ItemStack targetStack = entry.MealData != null ? BuildTempMealStack(entry.MealData) : entry.Stack;
                if (targetStack == null) return false;

                DummySlot dummySlot = new DummySlot(targetStack);
                return targetStack.Collectible.OnHeldInteractStep(secondsUsed, dummySlot, byPlayer.Entity, blockSel, null);

            }
        }

        //OnContainedInteractStop is the end bit of plate interaction
        public new void OnContainedInteractStop(float secondsUsed, BlockEntityContainer be, ItemSlot slot, IPlayer byPlayer, BlockSelection blockSel)
        {
            ItemStack stack = slot.Itemstack;
            IWorldAccessor world = api.World;
            Vec3d hitPosition = GetCorrectedHitPosition(be, blockSel.HitPosition);
            int gridSize = validCellsMask.GetLength(0);

            List<PlatedFoodEntry> items = GetPlatedItems(world, stack);
            var (cellX, cellZ) = HitPositionToGridCell(hitPosition, gridSize);
            PlatedFoodEntry? entry = GetEntryAt(cellX, cellZ, items);

            if (entry == null) return;
            else
            {
                if (entry.MealData != null)
                {
                    BlockMeal borrowedMeal = BlockMeal.RandomMealBowl(api);
                    ItemStack tempStack = BuildTempMealStack(entry.MealData);
                    if (tempStack == null) return;

                    DummySlot dummySlot = new DummySlot(tempStack);
                    tempStack.Collectible.OnHeldInteractStop(secondsUsed, dummySlot, byPlayer.Entity, blockSel, null);

                    float remainingServings = dummySlot.Itemstack == null
                        ? 0f
                        : borrowedMeal.GetQuantityServings(world, dummySlot.Itemstack);

                    if (remainingServings <= 0f)
                    {
                        RemoveEntry(entry, items, stack);
                    }
                    else
                    {
                        entry.MealData.QuantityServings = remainingServings;
                        SetPlatedItems(stack, items);
                    }
                }
                else
                {
                    DummySlot dummySlot = new DummySlot(entry.Stack);
                    entry.Stack.Collectible.OnHeldInteractStop(secondsUsed, dummySlot, byPlayer.Entity, blockSel, null);

                    if (dummySlot.Itemstack == null)
                    {
                        RemoveEntry(entry, items, stack);
                    }
                    else if (dummySlot.Itemstack != entry.Stack)
                    {
                        entry.Stack = dummySlot.Itemstack;
                        SetPlatedItems(stack, items);
                    }
                }
                be.MarkDirty(true);
            }
        }

        //gives accurate tooltip info for what's on plate (in hand)
        public override void GetHeldItemInfo(ItemSlot inSlot, StringBuilder dsc, IWorldAccessor world, bool withDebugInfo)
        {
            dsc.AppendLine("Material: " + BlockMaterial.ToString());
            dsc.AppendLine("Mod: Dishware");

            ItemStack stack = inSlot.Itemstack;
            List<PlatedFoodEntry> items = GetPlatedItems(world, stack);

            if (items.Count == 0)
            {
                dsc.AppendLine("(Empty)");
                return;
            }

            dsc.AppendLine("Plated:");
            foreach (var entry in items)
            {
                dsc.AppendLine($"- {GetEntryDisplayName(entry)}");
            }
        }

        public string GetContainedInfo(ItemSlot inSlot)
        {

            ItemStack containerStack = inSlot.Itemstack;
            IWorldAccessor world = api.World;
            List<PlatedFoodEntry> items = GetPlatedItems(world, containerStack);

            if (items.Count == 0)
            {
                return Lang.GetWithFallback("contained-empty-container", "{0} (Empty)", GetHeldItemName(containerStack));
            }

            return string.Join(", ", items
                .GroupBy(entry => GetEntryDisplayName(entry))
                .Select(g =>
                {
                    int count = g.Sum(e => e.MealData != null ? 1 : e.Stack.StackSize);
                    return count > 1 ? $"{g.Key} x{count}" : g.Key;
                }));
        }
        private string GetEntryDisplayName(PlatedFoodEntry entry)
        {
            if (entry.MealData != null)
            {
                CookingRecipe recipe = GetCookingRecipeAnySource(entry.MealData.RecipeCode);
                return recipe?.GetOutputName(api.World, entry.MealData.ContentStacks) ?? entry.MealData.RecipeCode;
            }
            return entry.Stack.GetName();
        }

        private ItemStack BuildTempMealStack(PlatedMealData mealData)
        {
            BlockMeal borrowedMeal = BlockMeal.RandomMealBowl(api);
            if (borrowedMeal == null) return null;

            ItemStack tempStack = new ItemStack(borrowedMeal, 1);
            borrowedMeal.SetContents(mealData.RecipeCode, tempStack, mealData.ContentStacks, mealData.QuantityServings);
            return tempStack;
        }

        //looks up a recipe from vanilla's cooking registry, falls back to any RecipeRegistryGeneric<CookingRecipe> (ACulinaryArtillery's "mixingrecipes") if not found
        public CookingRecipe GetCookingRecipeAnySource(string recipeCode)
        {
            CookingRecipe recipe = api.GetCookingRecipe(recipeCode);
            if (recipe != null) return recipe;

            if (api.World is GameMain gameMain)
            {
                var mixingRegistry = gameMain.GetRecipeRegistry("mixingrecipes") as RecipeRegistryGeneric<CookingRecipe>;
                recipe = mixingRegistry?.Recipes.FirstOrDefault(r => r.Code == recipeCode);
            }

            return recipe;
        }
        public float GetQuantityServings(IWorldAccessor world, ItemStack containerStack)
        {
            float result = GetPlatedItems(world, containerStack).Count > 0 ? 1f : 0f;
            return result;
        }

        public void SetQuantityServings(IWorldAccessor world, ItemStack containerStack, float quantityServings)
        {
            containerStack.Attributes.SetFloat("quantityServings", quantityServings);
        }

        public string GetRecipeCode(IWorldAccessor world, ItemStack containerStack)
        {
            return null;
        }

        public CookingRecipe GetCookingRecipe(IWorldAccessor world, ItemStack containerStack)
        {
            return null;
        }
    }



    //Plated food entry holds plate itemstack and relevant info
    public class PlatedFoodEntry
    {
        public ItemStack Stack;
        public PlatedMealData MealData;
        public int AnchorX;
        public int AnchorZ;
        public FootprintSize Footprint;
        public int RotationY;
    }

    public struct FootprintSize
    {
        public int Width;
        public int Height;

        public FootprintSize(int width, int height)
        {
            Width = width;
            Height = height;
        }
    }

    public struct FoodSize
    {
        public float Width;
        public float Height;
        public float OffsetX;
        public float OffsetZ;

        public FoodSize(float width, float height, float offsetX, float offsetZ)
        {
            Width = width;
            Height = height;
            OffsetX = offsetX;
            OffsetZ = offsetZ;
        }
    }
    public class PlateableMealsConfig
    {
        public PlateableMealEntry[] plateableRecipes = Array.Empty<PlateableMealEntry>();
    }

    public class PlateableMealEntry
    {
        public string recipeCode;
        public int footprintWidth = 4;
        public int footprintHeight = 4;
    }

    public class PlatedMealData
    {
        public string RecipeCode;
        public ItemStack[] ContentStacks;
        public float QuantityServings = 1f;
    }
}
    


