﻿using System;
using System.Collections.Generic;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.API.Util;
using Vintagestory.GameContent;

namespace Dishware.Blocks
{
    public class DishwareBowlLiquid : BlockLiquidContainerTopOpened, IContainedMeshSource
    {
        private class FillTier
        {
            public readonly AssetLocation ShapeLoc;
            public readonly float FloorY;
            public readonly float CeilingY;
            public readonly float Area;
            public Shape Shape;

            public float Volume => Area * (CeilingY - FloorY);

            public FillTier(AssetLocation shapeLoc, float floorY, float ceilingY, float area)
            {
                ShapeLoc = shapeLoc;
                FloorY = floorY;
                CeilingY = ceilingY;
                Area = area;
            }
        }

        private FillTier[] fillTiers;
        private MeshData cachedEmptyMesh;

        public override void OnLoaded(ICoreAPI api)
        {
            base.OnLoaded(api);

            JsonObject[] tierEntries = this.Attributes["dishwareFillTiers"].AsArray();
            //builds tiers for liquid fill amount in a bowl
            if (tierEntries == null)
            {
                api.Logger.Error("[Dishware] No dishwareFillTiers found on {0}; liquid contents will not render.", this.Code);
                fillTiers = new FillTier[0];
                return;
            }
            //goes through the number of tiers a given bowl has
            fillTiers = new FillTier[tierEntries.Length];
            for (int i = 0; i < tierEntries.Length; i++)
            {
                JsonObject entry = tierEntries[i];
                AssetLocation shapeLoc = new AssetLocation(this.Code.Domain, entry["shape"].AsString());
                fillTiers[i] = new FillTier(shapeLoc, entry["floorY"].AsFloat(), entry["ceilingY"].AsFloat(), entry["area"].AsFloat());
            }
        }

        // takes amount of liquid in bowl relative to full, translates nearest fill tier to match that percentage
        private bool TryGetFillTierAndTranslate(float currentLitres, out FillTier tier, out float translateY)
        {
            float totalVolume = 0f;
            foreach (var t in fillTiers) totalVolume += t.Volume;

            float cumulativeVolume = 0f;
            for (int i = 0; i < fillTiers.Length; i++)
            {
                FillTier t = fillTiers[i];
                float tierFloorLitres = this.CapacityLitres * cumulativeVolume / totalVolume;
                float tierCeilingLitres = this.CapacityLitres * (cumulativeVolume + t.Volume) / totalVolume;
                bool isLastTier = (i == fillTiers.Length - 1);

                if (currentLitres <= tierCeilingLitres || isLastTier)
                {
                    float range = tierCeilingLitres - tierFloorLitres;
                    float fraction = range > 0f ? (currentLitres - tierFloorLitres) / range : 1f;
                    fraction = GameMath.Clamp(fraction, 0f, 1f);

                    float heightRaw = t.FloorY + fraction * (t.CeilingY - t.FloorY);
                    tier = t;
                    translateY = (heightRaw - t.CeilingY) / 16f;
                    return true;
                }
                cumulativeVolume += t.Volume;
            }

            tier = null;
            translateY = 0f;
            return false;
        }

        // generates bowl with liquid mesh, figures out what tier its in and translates down
        public new MeshData GenMesh(ICoreClientAPI capi, ItemStack contentStack, BlockPos forBlockPos = null)
        {
            capi.World.Logger.Notification("[Dishware] GenMesh called for {0}", this.Code);
            if (this.cachedEmptyMesh == null)
            {
                Shape emptyShape = Vintagestory.API.Common.Shape.TryGet(capi, this.emptyShapeLoc.WithPathAppendixOnce(".json").WithPathPrefixOnce("shapes/"));
                if (emptyShape == null)
                {
                    capi.World.Logger.Error("Empty shape {0} not found. Liquid container {1} will be invisible.", this.emptyShapeLoc, this.Code);
                    return new MeshData(true);
                }
                capi.Tesselator.TesselateShape(this, emptyShape, out this.cachedEmptyMesh, new Vec3f(this.Shape.rotateX, this.Shape.rotateY, this.Shape.rotateZ), null, null);
            }
            MeshData meshData = this.cachedEmptyMesh.Clone();

            if (contentStack == null) return meshData;

            WaterTightContainableProps containableProps = BlockLiquidContainerBase.GetContainableProps(contentStack);
            if (containableProps == null)
            {
                capi.World.Logger.Error("Contents ('{0}') has no liquid properties, contents of liquid container {1} will be invisible.", contentStack.GetName(), this.Code);
                return meshData;
            }

            float currentLitres = (float)contentStack.StackSize / containableProps.ItemsPerLitre;
            if (!TryGetFillTierAndTranslate(currentLitres, out FillTier tier, out float translateY))
            {
                return meshData;
            }

            if (tier.Shape == null)
            {
                tier.Shape = Vintagestory.API.Common.Shape.TryGet(capi, tier.ShapeLoc.WithPathAppendixOnce(".json").WithPathPrefixOnce("shapes/"));
                if (tier.Shape == null)
                {
                    capi.World.Logger.Error("Fill tier shape {0} not found for {1}.", tier.ShapeLoc, this.Code);
                    return meshData;
                }
            }

            ContainerTextureSource texSource = new ContainerTextureSource(capi, contentStack, containableProps.Texture);
            capi.Tesselator.TesselateShape(this.GetType().Name, tier.Shape, out MeshData meshData2, texSource,
                new Vec3f(this.Shape.rotateX, this.Shape.rotateY, this.Shape.rotateZ), containableProps.GlowLevel, 0, 0, null, null);

            meshData2.Translate(0f, translateY, 0f);

            if (containableProps.ClimateColorMap != null)
            {
                int color = (forBlockPos != null)
                    ? capi.World.ApplyColorMapOnRgba(containableProps.ClimateColorMap, null, -1, forBlockPos.X, forBlockPos.Y, forBlockPos.Z, false)
                    : capi.World.ApplyColorMapOnRgba(containableProps.ClimateColorMap, null, -1, 196, 128, false);
                byte[] colorBytes = ColorUtil.ToBGRABytes(color);
                for (int i = 0; i < meshData2.Rgba.Length; i++)
                {
                    meshData2.Rgba[i] = (byte)(meshData2.Rgba[i] * colorBytes[i % 4] / byte.MaxValue);
                }
            }

            for (int j = 0; j < meshData2.FlagsCount; j++)
            {
                meshData2.Flags[j] = meshData2.Flags[j] & -4097;
            }

            meshData.AddMeshData(meshData2);

            if (forBlockPos != null)
            {
                meshData.CustomInts = new CustomMeshDataPartInt(meshData.FlagsCount);
                meshData.CustomInts.Count = meshData.FlagsCount;
                meshData.CustomInts.Values.Fill(268435456);
                meshData.CustomFloats = new CustomMeshDataPartFloat(meshData.FlagsCount * 2);
                meshData.CustomFloats.Count = meshData.FlagsCount * 2;
            }

            return meshData;
        }

        public new MeshData GenMesh(ItemSlot slot, ITextureAtlasAPI targetAtlas, BlockPos forBlockPos)
        {
            ItemStack content = base.GetContent(slot.Itemstack);
            return this.GenMesh(this.api as ICoreClientAPI, content, forBlockPos);
        }

        // inventory rendering
        public override void OnBeforeRender(ICoreClientAPI capi, ItemStack itemstack, EnumItemRenderTarget target, ref ItemRenderInfo renderinfo)
        {
            Dictionary<int, MultiTextureMeshRef> dictionary;
            if (capi.ObjectCache.TryGetValue(this.meshRefsCacheKey, out object obj))
            {
                dictionary = obj as Dictionary<int, MultiTextureMeshRef>;
            }
            else
            {
                dictionary = new Dictionary<int, MultiTextureMeshRef>();
                capi.ObjectCache[this.meshRefsCacheKey] = dictionary;
            }

            ItemStack content = base.GetContent(itemstack);
            if (content == null) return;

            int stackCacheHashCode = this.GetStackCacheHashCode(content);
            if (!dictionary.TryGetValue(stackCacheHashCode, out MultiTextureMeshRef modelRef))
            {
                MeshData data = this.GenMesh(capi, content, null);
                modelRef = dictionary[stackCacheHashCode] = capi.Render.UploadMultiTextureMesh(data);
            }
            renderinfo.ModelRef = modelRef;
        }
    }
}