﻿using Dishware.Blocks;
using System;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;
using Vintagestory.Client.NoObf;
using Vintagestory.GameContent;

namespace Dishware.Rendering
{
    public class PlatePreviewRenderer : IRenderer
    {
        private readonly ICoreClientAPI capi;
        private readonly WireframeCube cube;
        

        public double RenderOrder => 0.9;
        public int RenderRange => 24;

        public PlatePreviewRenderer(ICoreClientAPI capi)
        {
            this.capi = capi;
            this.cube = WireframeCube.CreateUnitCube(capi, -1);
        }

        public void OnRenderFrame(float deltaTime, EnumRenderStage stage)
        {
            BlockSelection blockSel = capi.World.Player.CurrentBlockSelection;
            if (blockSel == null) return;

            ItemSlot heldSlot = capi.World.Player.InventoryManager.ActiveHotbarSlot;
            if (heldSlot == null || heldSlot.Empty) return;

            AssetLocation heldCode = heldSlot.Itemstack.Collectible.Code;
            if (DishwarePlacementState.LastItemCode == null || !heldCode.Equals(DishwarePlacementState.LastItemCode))
            {
                DishwarePlacementState.PreviewRotation = 0;
                DishwarePlacementState.LastItemCode = heldCode;
            }

            BlockEntityGroundStorage beg = capi.World.BlockAccessor.GetBlockEntity(blockSel.Position) as BlockEntityGroundStorage;
            ItemStack plateStack = beg?.Inventory?.FirstNonEmptySlot?.Itemstack;
            if (plateStack?.Block is not BlockFilledPlate plate) return;

            FootprintSize baseFootprint;
            if (heldSlot.Itemstack.Collectible is BlockMeal heldMeal && heldMeal is not BlockFilledPlate && heldMeal is not BlockPie)
            {
                string heldRecipeCode = heldMeal.GetRecipeCode(capi.World, heldSlot.Itemstack);
                if (!plate.IsMealPlateable(heldRecipeCode)) return;
                baseFootprint = plate.GetMealFootprint(heldRecipeCode);
            }
            else if (heldSlot.Itemstack.Collectible is BlockCookedContainerBase heldPot)
            {
                string heldRecipeCode = heldPot.GetRecipeCode(capi.World, heldSlot.Itemstack);
                if (!plate.IsMealPlateable(heldRecipeCode)) return;
                if (heldPot.GetQuantityServings(capi.World, heldSlot.Itemstack) <= 0f) return;
                baseFootprint = plate.GetMealFootprint(heldRecipeCode);
            }
            else
            {
                if (!plate.IsPlateable(capi.World, heldSlot.Itemstack)) return;
                baseFootprint = plate.GetFootprint(heldSlot.Itemstack);
            }

            float angle = beg.MeshAngle;
            float cos = (float)Math.Cos(angle);
            float sin = (float)Math.Sin(angle);

            Vec3d rawHit = blockSel.HitPosition;
            double hx = rawHit.X - 0.5;
            double hz = rawHit.Z - 0.5;
            Vec3d correctedHit = new Vec3d(hx * cos - hz * sin + 0.5, rawHit.Y, hx * sin + hz * cos + 0.5);

            int gridSize = plate.GridSize;
            var items = plate.GetPlatedItems(capi.World, plateStack);
            var (cellX, cellZ) = BlockFilledPlate.HitPositionToGridCell(correctedHit, gridSize);
            FootprintSize footprint = (DishwarePlacementState.PreviewRotation % 2 == 1)
                ? new FootprintSize(baseFootprint.Height, baseFootprint.Width)
                : baseFootprint;
            ItemStack?[,] occupancy = plate.BuildOccupancyGrid(gridSize, items);
            bool canPlace = plate.CanPlaceFootprint(cellX, cellZ, footprint, occupancy);

            float cellWidth = 1f / gridSize;
            float x1 = cellX * cellWidth;
            float z1 = cellZ * cellWidth;
            float x2 = x1 + footprint.Width * cellWidth;
            float z2 = z1 + footprint.Height * cellWidth;

            (float x, float z) Rotate(float px, float pz)
            {
                float dx = px - 0.5f;
                float dz = pz - 0.5f;
                return (dx * cos + dz * sin + 0.5f, -dx * sin + dz * cos + 0.5f);
            }

            var c1 = Rotate(x1, z1);
            var c2 = Rotate(x2, z1);
            var c3 = Rotate(x1, z2);
            var c4 = Rotate(x2, z2);

            float minX = Math.Min(Math.Min(c1.x, c2.x), Math.Min(c3.x, c4.x));
            float maxX = Math.Max(Math.Max(c1.x, c2.x), Math.Max(c3.x, c4.x));
            float minZ = Math.Min(Math.Min(c1.z, c2.z), Math.Min(c3.z, c4.z));
            float maxZ = Math.Max(Math.Max(c1.z, c2.z), Math.Max(c3.z, c4.z));

            float yOffset = 0.09375f;
            BlockPos pos = blockSel.Position;
            EntityPlayer eplr = capi.World.Player.Entity;
            double worldX = pos.X + eplr.CameraPosOffset.X + minX;
            double worldY = pos.InternalY + eplr.CameraPosOffset.Y + yOffset;
            double worldZ = pos.Z + eplr.CameraPosOffset.Z + minZ;

            float lineWidth = 1.6f * capi.Settings.Float["wireframethickness"];
            Vec4f color = canPlace ? new Vec4f(0f, 0f, 0f, 0.75f) : new Vec4f(0.6f, 0f, 0f, 0.75f);

            cube.Render(capi, worldX, worldY, worldZ, maxX - minX, 0.0625f, maxZ - minZ, lineWidth, color);
        }

        public void Dispose()
        {
            cube.Dispose();
        }
    }
}