﻿using System;
using System.Collections.Generic;
using System.Text;
using Vintagestory.API.Common;

namespace Dishware.Rendering
{
    public static class DishwarePlacementState
    {
        public static int PreviewRotation = 0;
        public static AssetLocation LastItemCode;
    }
}
